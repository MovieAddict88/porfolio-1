<?php
define('DB_HOST', 'sql105.infinityfree.com');
define('DB_USER', 'if0_40028928');
define('DB_PASS', 'xoX6idhxBfRNmM');
define('DB_NAME', 'if0_40028928_portfolio');
?>